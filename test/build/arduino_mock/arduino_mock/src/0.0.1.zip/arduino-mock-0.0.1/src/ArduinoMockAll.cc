// Copyright 2015 http://switchdevice.com

#include "Arduino.cc"
#include "EEPROM.cc"
#include "Serial.cc"
#include "serialHelper.cc"
#include "Spark.cc"
#include "WiFi.cc"
#include "Wire.cc"

